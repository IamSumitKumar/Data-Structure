// Optimized implementation of Bubble sort
#include<iostream>
#include <stdio.h>
using namespace std; 
  
void swap(int *xp, int *yp) 
{ 
    int temp = *xp; 
    *xp = *yp; 
    *yp = temp; 
} 
// An optimized version of Bubble Sort 
void bubbleSort(int arr[], int n) 
{ 
   int i, j; 
   bool swapped; 
   for (i = 0; i < n-1; i++) 
   { 
     swapped = false; 
     for (j = 0; j < n-i-1; j++) 
     { 
        if (arr[j] > arr[j+1]) 
        { 
           swap(&arr[j], &arr[j+1]); 
           swapped = true; 
        } 
     } 
  
     // IF no two elements were swapped by inner loop, then break 
     if (swapped == false) 
        break; 
   } 
}
/*Counting no of comparisons
void bubbleSort(int arr[], int n)
{
    bool sorted = false;
    for(int pass = 1; pass < n.size() && !sorted; pass++)
    {
        sorted = true;
        int i;
        for(i = 0; i < n.size() - pass; i++)
        {
            if(*n[i + 1] < *n[i])
            {
                swap(n, i, i + 1);
                sorted = false;

            }
        }
        CountbubbleSort += i;
    }
    cout<<"bubbleSort comparison is "<<CountbubbleSort<<endl;
}*/
/* Function to print an array */
void printArray(int arr[], int size) 
{ 
    int i;
    cout<<"[";
    for (i=0; i < size; i++)
        cout<<arr[i]<<"][";
}
// Driver program to test above functions
int main()
{
    int arr[100];
    int n;
    cout<<"Enter the number of elements in array: ";
    cin>>n;
    for(int i = 0; i < n; i++){
    	cout<<"Enter the number-"<<i+1<<": ";
    	cin>>arr[i];
	}
    bubbleSort(arr, n);
    cout<<"\n\nSorted array: \n";
    printArray(arr, n);
    return 0;
}
